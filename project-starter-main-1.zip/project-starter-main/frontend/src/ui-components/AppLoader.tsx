export const AppLoader = () => <div>Loading...</div>;
