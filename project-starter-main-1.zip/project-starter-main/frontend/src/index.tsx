import './i18n';

import React from 'react';
import ReactDOM from 'react-dom';

import { AppIndex } from './indexFixed';

ReactDOM.render(<AppIndex />, document.getElementById('root'));
