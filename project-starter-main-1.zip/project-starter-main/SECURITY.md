# Security Policy

## Supported Versions

Default branch contains only supported version.
No forks are planned, and as soon code is forked into a new project we expect that project to be maintained seperately.
We do advise cherry-picking features, but security scans & updates are best to be done independently.

## Reporting a Vulnerability

Use built-in Issues trakcer for reporting Vulnerabilities.
